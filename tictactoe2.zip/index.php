<?php
use classes\Router;

include('common.php');

new Router();

