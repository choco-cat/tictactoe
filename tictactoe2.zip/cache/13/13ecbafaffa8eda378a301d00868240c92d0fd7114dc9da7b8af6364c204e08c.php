<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* footer.html */
class __TwigTemplate_8e6345af1e596d65ed5a0184e6b9349e6d71ce2cce3fc1b2ac47832fac24e74a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "</div>
</main>
<footer>
    <div class=\"container\">
        <p>Задание выполнила <a href=\"https://github.com/choco-cat\" target=\"_blank\">Панфиленко Наталья</a></p>
    </div>
</footer>
<script type=\"text/javascript\" src=\"./assets/js/jquery-3.6.1.min.js\"></script>
<script type=\"text/javascript\" src=\"./assets/js/main.js\"></script>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "footer.html";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "footer.html", "C:\\OSPanel2\\domains\\tictactoe\\view\\footer.html");
    }
}
