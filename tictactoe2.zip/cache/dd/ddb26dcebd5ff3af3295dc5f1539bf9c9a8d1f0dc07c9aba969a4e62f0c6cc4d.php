<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* header.html */
class __TwigTemplate_33263e3ea4e172e4b96b2886c69799d7a5a8307b8df1dc951b4edeefcdcb5f98 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!doctype html>
<html>
<head>
    <link href=\"./assets/css/main.css\" rel=\"stylesheet\">
</head>
<body>
<header>
    <nav>
        <div class=\"container\">
            <ul>
                <li><a href=\"./\">Главная</a></li>
                ";
        // line 12
        if ( !($context["auth"] ?? null)) {
            // line 13
            echo "                <li><a href=\"./registration\">Регистрация</a></li>
                <li><a href=\"./login\">Авторизация</a></li>
                ";
        } else {
            // line 16
            echo "                <li><a href=\"./login/logout\">Выйти</a></li>
                ";
        }
        // line 18
        echo "                <hr/>
            </ul>
        </div>
    </nav>
</header>
<main>
    <div class=\"container\">
        ";
        // line 25
        if (($context["login"] ?? null)) {
            // line 26
            echo "        <div class=\"statistics\">
            <p>Пользователь: ";
            // line 27
            echo twig_escape_filter($this->env, ($context["login"] ?? null), "html", null, true);
            echo "</p>
            ";
        }
        // line 29
        echo "            ";
        if (($context["level"] ?? null)) {
            // line 30
            echo "            <p>Уровень: <span id=\"level\">";
            echo twig_escape_filter($this->env, ($context["level"] ?? null), "html", null, true);
            echo "</span></p>
        </div>
        ";
        }
        // line 33
        echo "        <h1>Крестики-нолики</h1>
        <h2>";
        // line 34
        echo twig_escape_filter($this->env, ($context["page_title"] ?? null), "html", null, true);
        echo "</h2>
";
    }

    public function getTemplateName()
    {
        return "header.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 34,  90 => 33,  83 => 30,  80 => 29,  75 => 27,  72 => 26,  70 => 25,  61 => 18,  57 => 16,  52 => 13,  50 => 12,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "header.html", "C:\\OSPanel2\\domains\\tictactoe\\view\\header.html");
    }
}
